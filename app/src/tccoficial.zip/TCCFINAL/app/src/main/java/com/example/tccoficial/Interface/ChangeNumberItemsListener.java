package com.example.tccoficial.Interface;

public interface ChangeNumberItemsListener {
    void changed();
}
